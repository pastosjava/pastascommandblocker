package com.pastas.commandblocker.listeners;

import com.pastas.commandblocker.PastasCommandBlocker;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

import java.util.List;

public class CommandListener implements Listener {

    private final PastasCommandBlocker plugin;

    public CommandListener(PastasCommandBlocker plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onCommand(PlayerCommandPreprocessEvent event) {

        Player player = event.getPlayer();

        FileConfiguration config = plugin.getConfig();

        if (player.hasPermission(
                config.getString("settings.bypass-permission")
        )) {
            return;
        }

        String message = event.getMessage().toLowerCase();

        List<String> blockedCommands =
                config.getStringList("blocked-commands");

        for (String blocked : blockedCommands) {

            blocked = blocked.toLowerCase();

            if (message.equals(blocked)
                    || message.startsWith(blocked + " ")) {

                event.setCancelled(true);

                if (config.getBoolean("messages.enabled")) {

                    player.sendMessage(color(
                            config.getString("messages.blocked")
                    ));
                }

                if (config.getBoolean("sounds.enabled")) {

                    try {

                        Sound sound = Sound.valueOf(
                                config.getString("sounds.sound")
                        );

                        player.playSound(
                                player.getLocation(),
                                sound,
                                (float) config.getDouble("sounds.volume"),
                                (float) config.getDouble("sounds.pitch")
                        );

                    } catch (Exception ignored) {
                    }
                }

                return;
            }
        }
    }

    private String color(String text) {

        return ChatColor.translateAlternateColorCodes(
                '&',
                text
        );
    }
}
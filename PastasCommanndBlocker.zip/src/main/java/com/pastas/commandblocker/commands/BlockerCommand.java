package com.pastas.commandblocker.commands;

import com.pastas.commandblocker.PastasCommandBlocker;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class BlockerCommand implements CommandExecutor {

    private final PastasCommandBlocker plugin;

    public BlockerCommand(PastasCommandBlocker plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(
            CommandSender sender,
            Command command,
            String label,
            String[] args
    ) {

        if (!sender.hasPermission("pastascommandblocker.admin")) {

            sender.sendMessage(color(
                    plugin.getConfig().getString(
                            "messages.no-permission"
                    )
            ));

            return true;
        }

        if (args.length == 1) {

            if (args[0].equalsIgnoreCase("reload")) {

                plugin.reload();

                sender.sendMessage(color(
                        plugin.getConfig().getString(
                                "messages.reload"
                        )
                ));

                return true;
            }
        }

        sender.sendMessage(color("&cUsage: /pcb reload"));

        return true;
    }

    private String color(String text) {

        return ChatColor.translateAlternateColorCodes(
                '&',
                text
        );
    }
}
package com.pastas.commandblocker;

import com.pastas.commandblocker.commands.BlockerCommand;
import com.pastas.commandblocker.listeners.CommandListener;
import org.bukkit.plugin.java.JavaPlugin;

public class PastasCommandBlocker extends JavaPlugin {

    private static PastasCommandBlocker instance;

    public static PastasCommandBlocker getInstance() {
        return instance;
    }

    @Override
    public void onEnable() {

        instance = this;

        saveDefaultConfig();

        getServer().getPluginManager().registerEvents(
                new CommandListener(this),
                this
        );

        getCommand("pcb").setExecutor(new BlockerCommand(this));

        getLogger().info("[PastasCommandBlocker] Plugin enabled.");
    }

    @Override
    public void onDisable() {
        getLogger().info("[PastasCommandBlocker] Plugin disabled.");
    }

    public void reload() {
        reloadConfig();
    }
}